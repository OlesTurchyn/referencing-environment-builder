#include "lexical_analyzer.h"
#include "expression_evaluator.h"
#include "referencing_environment.h"
#ifndef SYNTAX_ANALYZER_H
#define SYNTAX_ANALYZER_H


void analyze_syntax();


#endif