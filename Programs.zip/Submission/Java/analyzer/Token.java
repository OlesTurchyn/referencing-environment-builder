package analyzer;
public class Token {
    public  int code;
    public  int line;
    public String lexeme;
}