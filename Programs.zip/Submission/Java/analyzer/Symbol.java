package analyzer;

public class Symbol {
    String type;
    String name;
    String value;
    

    public Symbol() {
        this.type = "";
        this.name = "";
        this.value = "";
    } 
}
