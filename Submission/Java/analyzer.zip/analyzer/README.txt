CSI 3120 Assignment 3
Implementing a Reference Builder

Student: Oleksander Turchyn
Student Number: 300174825

EXECUTION INSTRUCTIONS:
-------------------------
1) Edit line 64 in LexicalAnalyzer.java to change the input file name to the test case
you wish to run (ie: input1.txt)
2) Compile Java files by running javac *.javac
3) Run SyntaxAnalyzer.java
4) See output in your command line interface

Completing these steps for all 10 input files will get the outputs. 
